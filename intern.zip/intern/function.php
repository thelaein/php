<?php
function Name($name, $year) {
  echo "My name is $name . Born in $year <br>";
}

Name("Mg","1975");
Name("Su","1978");
Name("Mya","1983");
?>

