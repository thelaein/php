<?php
$name="ma";
switch($name){
    case "ma":
        echo "my name is ma";
    break;
    case "Su":
        echo "your name is Su";
    break;
    case "Aye":
        echo "my friend name is Aye";
    break; 
}
?>