<?php
echo strlen("Hello world.......");
?> 
<?php
echo str_word_count("H e l l o");
?>
<?php
echo strrev("olleh world");
?> 
<?php
echo strpos("Hellooo world", "world");
?> 
<?php
echo str_replace("world", "hello", "Hello world!");
?> 