<?php
ECHO "Hello World!<br>";
echo "Hello World!<br>";
EcHo "Hello World!<br>" . "<br>";
?>

<?php
$name="Thel";
$num=30+8;
echo "<h3>My name is $name </h3>" ;
echo "roll no is" . $num . "<br>" . "<br>";
?>